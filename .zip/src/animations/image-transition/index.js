const { default: mouseFollower } = require("./mousefollower");
const imageTransition = () => {
};

export default imageTransition;
