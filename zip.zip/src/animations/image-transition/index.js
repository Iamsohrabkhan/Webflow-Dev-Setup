const imageTransition = () => {
};

export default imageTransition;
