import gsap from "gsap";

const defaultNavbar = () => {
  console.log("default");
  
  const navbar = document.querySelector(".navbar-home");
  const targets = [".hamburger", ".navbar-log h2", ".cta-01"];

  if (!navbar) return;

  gsap.set(targets, { filter: "invert(100%)" });
  gsap.set(navbar, { backgroundColor: "#f4f3f1" });
};

export default defaultNavbar;
